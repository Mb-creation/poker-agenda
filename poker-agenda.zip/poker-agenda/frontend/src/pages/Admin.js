import { useEffect, useState } from "react";
import EditEventForm from "./EditEventForm";

export default function Admin() {
  const [evenements, setEvenements] = useState([]);
  const [message, setMessage] = useState("");
  const [editEvent, setEditEvent] = useState(null);

  // Pour le formulaire d'ajout
  const [titre, setTitre] = useState("");
  const [type, setType] = useState("tournoi");
  const [date, setDate] = useState("");
  const [lieu, setLieu] = useState("");
  const [description, setDescription] = useState("");

  // Charger les événements
  const fetchEvents = () => {
    fetch("/api/evenements")
      .then((res) => res.json())
      .then(setEvenements);
  };

  useEffect(() => {
    fetchEvents();
  }, []);

  // Ajouter un événement
  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await fetch("/api/evenements", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ titre, type, date, lieu, description }),
    });
    const data = await res.json();
    if (data.evenement) {
      setMessage("Événement ajouté !");
      setTitre("");
      setType("tournoi");
      setDate("");
      setLieu("");
      setDescription("");
      fetchEvents();
    } else {
      setMessage(data.message || "Erreur lors de l'ajout");
    }
  };

  // Supprimer un événement
  const supprimer = async (id) => {
    if (!window.confirm("Supprimer cet événement ?")) return;
    const res = await fetch(`/api/evenements/${id}`, { method: "DELETE" });
    const data = await res.json();
    setMessage(data.message);
    fetchEvents();
  };

  // Modifier un événement (ouvre le formulaire d'édition)
  const modifier = (event) => {
    setEditEvent(event);
  };

  // Callback après édition
  const onEditDone = () => {
    setEditEvent(null);
    fetchEvents();
  };

  return (
    <div>
      <h2>Ajouter un événement</h2>
      {message && <div style={{ color: "green" }}>{message}</div>}
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Titre"
          value={titre}
          onChange={(e) => setTitre(e.target.value)}
          required
        />
        <select value={type} onChange={(e) => setType(e.target.value)}>
          <option value="tournoi">Tournoi</option>
          <option value="cash_game">Cash Game</option>
        </select>
        <input
          type="datetime-local"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          required
        />
        <input
          type="text"
          placeholder="Lieu"
          value={lieu}
          onChange={(e) => setLieu(e.target.value)}
          required
        />
        <textarea
          placeholder="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
        <button type="submit">Ajouter</button>
      </form>

      <h2>Liste des événements</h2>
      <ul>
        {evenements.map((ev) => (
          <li key={ev.id}>
            <b>{ev.titre}</b> ({ev.type}) — {new Date(ev.date).toLocaleString()} à {ev.lieu}
            <button onClick={() => modifier(ev)}>Modifier</button>
            <button onClick={() => supprimer(ev.id)}>Supprimer</button>
          </li>
        ))}
      </ul>

      {editEvent && (
        <EditEventForm event={editEvent} onDone={onEditDone} onCancel={() => setEditEvent(null)} />
      )}
    </div>
  );
}