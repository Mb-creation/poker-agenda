import { useState } from "react";

export default function EditEventForm({ event, onDone, onCancel }) {
  const [titre, setTitre] = useState(event.titre);
  const [type, setType] = useState(event.type);
  const [date, setDate] = useState(event.date.slice(0, 16)); // Pour datetime-local
  const [lieu, setLieu] = useState(event.lieu);
  const [description, setDescription] = useState(event.description || "");
  const [message, setMessage] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await fetch(`/api/evenements/${event.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ titre, type, date, lieu, description }),
    });
    const data = await res.json();
    if (data.evenement) {
      setMessage("Événement modifié !");
      onDone();
    } else {
      setMessage(data.message || "Erreur lors de la modification");
    }
  };

  return (
    <div style={{ border: "1px solid #ccc", padding: 10, margin: 10 }}>
      <h3>Modifier l'événement</h3>
      {message && <div style={{ color: "green" }}>{message}</div>}
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Titre"
          value={titre}
          onChange={(e) => setTitre(e.target.value)}
          required
        />
        <select value={type} onChange={(e) => setType(e.target.value)}>
          <option value="tournoi">Tournoi</option>
          <option value="cash_game">Cash Game</option>
        </select>
        <input
          type="datetime-local"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          required
        />
        <input
          type="text"
          placeholder="Lieu"
          value={lieu}
          onChange={(e) => setLieu(e.target.value)}
          required
        />
        <textarea
          placeholder="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
        <button type="submit">Enregistrer</button>
        <button type="button" onClick={onCancel} style={{ marginLeft: 10 }}>
          Annuler
        </button>
      </form>
    </div>
  );
}