const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const sequelize = require('./models/sequelize');
const User = require('./models/User');
const Evenement = require('./models/Evenement');
const Inscription = require('./models/Inscription');

const authRoutes = require('./routes/auth');
const evenementRoutes = require('./routes/evenements');
const inscriptionRoutes = require('./routes/inscriptions');

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.use('/api', authRoutes);
app.use('/api', evenementRoutes);
app.use('/api', inscriptionRoutes);

sequelize.sync().then(() => {
  app.listen(3000, () => {
    console.log('Serveur backend démarré sur http://localhost:3000');
  });
});
