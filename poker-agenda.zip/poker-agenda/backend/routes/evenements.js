const express = require('express');
const router = express.Router();
const Evenement = require('../models/Evenement');

// Créer un événement (admin)
router.post('/evenements', async (req, res) => {
  const { titre, type, date, lieu, description } = req.body;
  if (!titre || !type || !date || !lieu) {
    return res.status(400).json({ message: "Champs requis manquants" });
  }
  const evenement = await Evenement.create({ titre, type, date, lieu, description });
  res.status(201).json({ evenement });
});

// Modifier un événement (admin)
router.put('/evenements/:id', async (req, res) => {
  const { titre, type, date, lieu, description } = req.body;
  const evenement = await Evenement.findByPk(req.params.id);
  if (!evenement) return res.status(404).json({ message: "Événement introuvable" });
  await evenement.update({ titre, type, date, lieu, description });
  res.json({ evenement });
});

// Supprimer un événement (admin)
router.delete('/evenements/:id', async (req, res) => {
  const evenement = await Evenement.findByPk(req.params.id);
  if (!evenement) return res.status(404).json({ message: "Événement introuvable" });
  await evenement.destroy();
  res.json({ message: "Événement supprimé" });
});

// Liste des événements
router.get('/evenements', async (req, res) => {
  const evenements = await Evenement.findAll();
  res.json(evenements);
});

module.exports = router;