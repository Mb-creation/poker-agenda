const { Sequelize } = require('sequelize');

// Ici, tu peux changer le dialecte ou la base selon tes besoins
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: './database.sqlite'
});

module.exports = sequelize;
