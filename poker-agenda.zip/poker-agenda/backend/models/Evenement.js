const { DataTypes } = require('sequelize');
const sequelize = require('./sequelize');

const Evenement = sequelize.define('Evenement', {
  titre: {
    type: DataTypes.STRING,
    allowNull: false
  },
  type: {
    type: DataTypes.ENUM('tournoi', 'cash_game'),
    allowNull: false
  },
  date: {
    type: DataTypes.DATE,
    allowNull: false
  },
  lieu: {
    type: DataTypes.STRING,
    allowNull: false
  },
  description: {
    type: DataTypes.TEXT
  }
});

module.exports = Evenement;