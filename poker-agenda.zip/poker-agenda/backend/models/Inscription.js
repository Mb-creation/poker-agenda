const { DataTypes } = require('sequelize');
const sequelize = require('./sequelize');
const User = require('./User');
const Evenement = require('./Evenement');

const Inscription = sequelize.define('Inscription', {});

User.belongsToMany(Evenement, { through: Inscription });
Evenement.belongsToMany(User, { through: Inscription });

module.exports = Inscription;